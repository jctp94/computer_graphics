// =========================================================================
// @author Leonardo Florez-Valencia (florez-l@javeriana.edu.co)
// =========================================================================

#include <iostream>
#include <PUJ_GL/BaseApp.h>
#include <GL/glut.h>

/**
 */
class MyApp
  : public PUJ_GL::BaseApp
{
public:
  using Self       = MyApp;
  using Superclass = PUJ_GL::BaseApp;

public:
  MyApp(
    int* argc, char** argv,
    int mode = GLUT_SINGLE | GLUT_RGB,
    int w = 500, int h = 500,
    int x = 10, int y = 10
    )
    : Superclass( argc, argv, mode, w, h, x, y, "Hello world!" )
    {
    }
  virtual ~MyApp( )
    {
    }

  virtual void init( ) override
    {
      this->Superclass::init( );

      glClearColor( 0.0, 0.0, 0.0, 1.0 );
    }

protected:
  virtual void _cb_display( ) override
    {
      glClear( GL_COLOR_BUFFER_BIT );
      glFlush( );
    }
};

// -------------------------------------------------------------------------
int main( int argc, char** argv )
{
  MyApp app( &argc, argv );
  app.init( );
  app.go( );

  return( EXIT_SUCCESS );
}

// eof - main.cxx
